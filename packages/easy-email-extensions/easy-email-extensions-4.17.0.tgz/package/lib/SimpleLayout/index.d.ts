export { SimpleLayout } from './SimpleLayout';
